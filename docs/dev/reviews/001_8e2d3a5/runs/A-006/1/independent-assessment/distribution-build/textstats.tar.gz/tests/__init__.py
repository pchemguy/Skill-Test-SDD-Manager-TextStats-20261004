"""Product test discovery package."""
